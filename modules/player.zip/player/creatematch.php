<?php 
$currId = MYID;
$showList = userModel::userDetails($currId);
$getemail = $showList->emailadd;
$getfname = $showList->fname;
if(isset($_REQUEST['msg']) && $_REQUEST['msg']=="success")
	{
	echo '<div class="col-md-12 text-center isa_success" style="color:red;">
      <p>New game has successfull been created. An email has been sent to you, with a lias name, also an alert has been sent to nofitcations section.</p>
	  <p>Please check Notification menu for mor info</p>
		 </div>';
	
	return;
	} 


if(isset($_POST['submitCustomGame']) && $_POST['submitCustomGame'] == "Submit Game")
	{
	
	if(!isset($_POST['gameCategoryId']) || !isset($_POST['gameConsoleId']) || !isset($_POST['stake']) )
		{
		echo '<div class="col-md-12 isa_error text-center">You have to fill all the details.</div>';
		}
	else
		{
		    
			echo dashboardModel::userSubmitMyGame($_POST);
	
			}//termsandconditions
		} 

?>

<?php
if(isset($_REQUEST['msg']) && $_REQUEST['msg']=="email_error")
	echo '<div class="col-md-12 text-center isa_error">Your registration details have been submitted. There was a problem relaying email. please contact admin.</div>';
?> 
 
 <form class="form" role="form" method="post" action="index.php?acc=games&page=creatematch" id="signup-nav2">
    <div class="col-md-12 form-group">
    <input type="hidden" name="userId" value="<?php echo $currId;?>">
    
    <input type="hidden" name="myemail" value="<?php echo $getemail;?>">
    
    <input type="hidden" name="fname" value="<?php echo $getfname;?>">
    
    </div>
   
   <div class="col-md-12 form-group">
     
          <div class="col-md-6">
          <label>Game Category</label>
          <select class="browser-default custom-select"  name="gameCategoryId">
          <option selected>Select Game Category</option>
         <?php 
         //echo dashboardModel::getAllCategory();
         $categoryList2 = dashboardModel::listAllGameCategory();
         if(count($categoryList2) < 1 ):
         echo '<div class="col-md-12 isa_warning text-center">There are no game category</div>';
         else:
         ?>
       <?php 
       foreach($categoryList2 as $catcListx)
       {?>
        <option value="<?php echo $catcListx->id; ?>" name="gameCategoryId"><?php echo $catcListx->gametitle; ?></option>
       <?php
       }
       endif;
       ?>
         </select>
         </div>
         <div class="col-md-6">
         <?php 
         $usr = userModel::userDetails($currId);
         //print_r($usr);
         ?>
         <div class="col-md-6">
         <label>My Console</label>
          <input type="hidden" name="gameConsoleId" value="<?php echo $usr->consoleId;?>">
    	<label>::<strong><?php echo $usr->consoleId;?></strong></label>
    	</div>
         </div>
        
         </div>
         <div class="col-md-12 form-group">
         <div class="col-md-4">
         <label>Your Stake</label>
        <div class="numbers-row">
        <input type="text" name="stake" style="float: left;width: 40px;padding: 3px 0 0 0;text-align: center;" id="french-hens" value="100">
          </div>
        </div>  
        <div class="col-md-4">
            <label class="sr-only" for="exampleInputEmail2">Team star level</label>
          <select class="browser-default custom-select" name="starlevel">
          <option selected>Any star level</option>
          <option value="4½">4 ½ star and below</option>
          <option value="4">4 star and below</option>
          <option value="3½">3 ½ star and below</option>
          <option value="3">3 star and below</option>
         </select>
         </div> 
         <div class="col-md-4">
            <label class="sr-only" for="exampleInputEmail2">Rules</label>
          <select class="browser-default custom-select" name="gamerules">
          <option selected>Half length</option>
          <option value="4">4 minutes</option>
          <option value="5">5 minutes</option>
          <option value="6">6 minutes</option>
          <option value="7">7 minutes</option>
          <option value="8">8 minutes</option>
         </select>
 
         </div>
         </div>
     
         <div class="col-md-12 form-group">
    	<div class="col-md-12 text-center">
    	<?php 
    	if($balance < MIN_ENTRY_FEE || $balance < $row->entry_fee ){
    	echo '<p class="text-center isa_error">Your current balance is low. Please top up to play</p>';
    	}else {
    		echo '<input type="submit" name="submitCustomGame" class="btn btn-success" value="Submit Game" />';
    	}
    	?>
       		
            
    	</div>
        </div>
    
       
         
         <script type="text/javascript">

     $(document).ready(function(){
         $("select").change(function(){
             $( "select option:selected").each(function(){
                 if($(this).attr("value")=="ps4"){
                     $(".box").hide();
                     $("#ps4").show();
                 }
                 if($(this).attr("value")=="green"){
                     $(".box").hide();
                     $(".green").show();
                 }
                 if($(this).attr("value")=="blue"){
                     $(".box").hide();
                     $(".blue").show();
                 }
                 if($(this).attr("value")=="choose"){
                     $(".box").hide();
                     $(".choose").show();
                 }
             });
         }).change();
     });
     </script> 
  <script type="text/javascript">

$(function() {

	  $(".numbers-row").append('<div class="inc button2">+</div><div class="dec button2">-</div>');

	  $(".button2").on("click", function() {

	    var $button = $(this);
	    var oldValue = $button.parent().find("input").val();

	    if ($button.text() == "+") {
	  	  var newVal = parseFloat(oldValue) + 50;
	  	} else {
		   // Don't allow decrementing below zero
	      if (oldValue > 100) {
	        var newVal = parseFloat(oldValue) - 50;
		    } else {
	        newVal = 100;
	      }
		  }

	    $button.parent().find("input").val(newVal);

	  });

	});
</script>

  </form>