<?php

$urls = 'index.php?acc=games';

$page = $_REQUEST['page'];

$gid = $_REQUEST['gid'];

$currentgameId = $_REQUEST['currentgameId'];

switch($page)
	{
	
	case "invite":
		include "invite".EXT;
		break;	
	
	case "details":
		include "game-details".EXT;
		break;
		
	case "claims":
		include "claim-prize".EXT;
		break;
		
	case "player1_prize":
		include "prize1".EXT;
		break;
		
	case "player2_dispute2":
		include "player2_dispute2".EXT;
		break;
		
	case "player1_dispute":
		include "player1_dispute".EXT;
		break;
		
	case "player1_dispute2":
		include "player1_dispute2".EXT;
		break;
		
	case "player2_dispute":
		include "player2_dispute".EXT;
		break;
		
	case "player2_prize":
		include "prize2".EXT;
		break;
		
		
	case "matchmaking":
		include "matchmaking".EXT;
		break;
		
	case "direct_message":
		include "direct_message".EXT;
		break;
	
	case "games-mine":
		include "games-mine".EXT;
		break;
		
	case "cancel_mygame":
		include "cancel_mygame".EXT;
		break;
		
	case "custom":
		include "custom".EXT;
		break;
		
	case "creatematch":
		include "creatematch".EXT;
		break;
		
	case "tournament":
		include "tournament".EXT;
		break;
	
	case "games-all":
		include "games-all" . EXT;
		break;
		
	default:
		include "games-all".EXT;
		break;
		
	default:
		include "addmessage".EXT;
		break;
		
	default:
		include "showmessage".EXT;
		break;
		
	default:
		include "messages".EXT;
		break;
		
	default:
		include "gamesactive".EXT;
		break;
		
	default:
		include "directmessage".EXT;
		break;
	
	}


?>

