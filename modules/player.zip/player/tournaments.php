<?php 
$gamesList = playModel::getBalanceByUserId(MYID);
//print_r($gamesList);
?>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Date

      </th>
      <th class="th-sm">Amount

      </th>
      <th class="th-sm">Deposit | Withdrawal</th>

    </tr>
  </thead>
  <tbody>
  
 <?php 
  
  if(count($gamesList) < 1 ):
  echo '<div class="col-md-12 isa_warning text-center">There are no games</div>';
  else:
  
  foreach($gamesList as $game)
  {
  	$d = $game->date_created;
  	$categId = $game->gamecategory_id;
  	$oppId = $game->player_2;
  	$gamesta = $game->game_status;
  	$tes = dashboardModel::getGameByCategoryId($categId);
  	
  	if($gamesta==0){
  		$status="pending";
  	}else{
  		$status="active";
  	}
  	//echo $oppId;
  	
  	echo '<tr>
            <td>'.$d.'</td>'
  		. '<td>'.$game->amount_deposited.'</td>'
  		. '<td>'.$game->balance_status.'</td></tr>';
  	
  }
  endif;
  ?>
  </tbody>
  </table>



