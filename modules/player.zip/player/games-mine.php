<?php

$gamesList = playModel::listMyGameHistoryByPlayerID(MYID);

//print_r($gamesList);
$urls = 'index.php?acc=games';

?>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Date & Time</th>
      <th class="th-sm">Game</th>
     
      <th class="th-sm">Stake</th>
      <th class="th-sm">Status

      </th>
    </tr>
  </thead>
  <tbody>
  <?php 
  
  if(count($gamesList) < 1 ):
  echo '<div class="col-md-12 isa_warning text-center">There are no games</div>';
  else:
  
  foreach($gamesList as $game)
  {
  	$d = $game->date_created;
  	$categId = $game->gamecategory_id;
  	$oppId = $game->player_2;
  	if($game->player_1_result==No){
  	 $play1winstatus ="Lose";	
  	}else {
  	 $play1winstatus ="Won";	
  	}
  	//check player 2
  	if($game->player_2_result=="No" && $game->player_1_result=="Yes"){
  		$play2winstatus ="Lose";
  	}else if($game->player_2_result=="Yes" && $game->player_1_result=="No"){
  		$play2winstatus ="Won";
  	}else {
  		$play2winstatus ="<strong>cancelled </strong>";
  	}
  	$gamesta = $game->game_status;
  	$cancel = $game->cancellation_status;
  
  	if($oppId=="NULL"){
  	 $opti ="No opponent";
  	}else {
  		$getopp = userModel::userDetails($oppId);
  		$opti = $getopp->alias;
  	}
  	$tes = dashboardModel::getGameByCategoryId($categId);
  	
  	$getRewardId = playModel::oneplayer1History(MYID);
  	
  	$getRewardId2 = playModel::oneplayer2History(MYID);
  
  	$status="<strong> $getRewardId2->win_status </strong>";
  	
  	if($gamesta==0 && $cancel !="cancelled" ){
  		$status="pending";
  	}else if($cancel=="cancelled"){
  		$status="cancelled";
  	}else if(MYID==$getRewardId->player_1 && $game->id == $getRewardId->gameId){
  		$status= "<strong> $getRewardId->win_status </strong>";
  	
  	}else if(MYID==$getRewardId2->player_1){
  		$status=$getRewardId2->win_status;
  	}
  	//echo $oppId;
  	
  	
  	echo '<tr>
            <td>'.$d.'</td>'
		    . '<td>'.$tes->gametitle.'</td>'
      		. '<td>'.$game->player1_stake.'</td>'
  		    . '<td>'.$status.'</td></tr>';
  	}
  
  endif;
  ?>
  </tbody>
  </table>

