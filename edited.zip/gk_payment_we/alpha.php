<?php 
// function increment(&$string){
//    $last_char=substr($string,-1);
//    $rest=substr($string, 0, -1);
//    switch ($last_char) {
//    case '':
//        $next= 'A';
//        break;
//    case 'Z':
//        $next= '0';
//        break;
//    case '9':
//        increment($rest);
//        $next= 'A';
//        break;
//    default:
//        $next= ++$last_char;
//    }
//    $string=$rest.$next;
//}
//
//    //sample
//    $string='AAAAAA';
//    for($i=1;$i<=12000;$i++){
//        echo $string."<br>";
//        increment($string);
//    }
    ?>

