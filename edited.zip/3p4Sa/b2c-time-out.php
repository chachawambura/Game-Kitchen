<?php
    require_once "../includes/configs.php";


?>