<div class="col-md-12 games">
 <div class="row">
 <div id="searchfilter" align="left"><h1>Messages</h1></div>
 </div>
 <div class="col-md-5">
 <form class="form" role="form" method="post" action="index.php?acc=games&page=messages" id="signup-nav2">
    <div class="col-md-12 form-group">
    <label>Title:</label>
    <input type="text" name="title">
   </div>
     
     <div class="col-md-12 form-group">
    <label>Message:</label>
    <textarea rows="5" cols="30"></textarea>
    </div>
      <div class="col-md-12 text-center">
       		<input type="submit" name="submitCustomGame" class="btn btn-success" value="Send" />
            
    	</div>
   </form>
 
 </div>
 
 <div class="col-md-7">
 <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
    
      <th class="th-sm">Id</th>
      <th class="th-sm">title</th>
      <th class="th-sm">desc</th>
      <th class="th-sm">Date</th>
      
    </tr>
  </thead>
  <tbody>
 </tbody>
 </table>
 
 </div>
 
 </div>