<div class="col-md-12 games">
	
    <h2 class="subheading">Open Matches</h2>
	
    <div class="row">
        <div id="searchfilter" align="left">
            <select >
                <option id="seleoption"class="filter-button" data-filter="sprinkle">Sprinkle Pipes</option>
                <option id="seleoption" class="filter-button" data-filter="hdpe">HDPE Pipes</option>
            </select>
            <select >
                <option id="seleoption" class="filter-button" data-filter="spray">Spray Nozzle</option>
                <option id="seleoption" class="filter-button" data-filter="irrigation">Irrigation Pipes</option>
            </select>
              <button class="filter-button" data-filter="all">Show All</button>
        </div>
        <br/>
        <div class="gallery_product col-md-6  filter hdpe">
            <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
        <div class="gallery_product col-md-6  filter hdpe">
            <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
        <div class="gallery_product col-md-6  filter hdpe">
           <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
        <div class="gallery_product col-md-6  filter hdpe">
            <div class="col-md-6"><img src="products/football.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product col-md-6 filter sprinkle">
         <div class="col-md-6"><img src="products/crikets.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product col-md-6 filter sprinkle">
         <div class="col-md-6"><img src="products/crikets.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>


        <div class="gallery_product  col-md-6   filter irrigation">
             <div class="col-md-6"><img src="products/shield.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product  col-md-6   filter spray">
             <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>


        <div class="gallery_product  col-md-6  filter spray">
             <div class="col-md-6"><img src="products/shield.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product col-md-6  filter irrigation">
           <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product col-md-6  filter irrigation">
           <div class="col-md-6"><img src="products/football.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product col-md-6 filter irrigation">
            <div class="col-md-6"><img src="products/football.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>>
            </div>
        </div>


        <div class="gallery_product  col-md-6  filter spray">
           <div class="col-md-6"><img src="products/football.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
        <div class="gallery_product  col-md-6  filter spray">
           <div class="col-md-6"><img src="products/football.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>

        <div class="gallery_product  col-md-6 filter sprinkle">
            <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
        <div class="gallery_product  col-md-6 filter sprinkle">
            <div class="col-md-6"><img src="products/fortune.jpg" class="img-responsive"></div>
            <div class="col-md-6">
               <h4><strong>Fortnite</strong></h4>
               <p>PS4 Tournament<br>Prizes: $10.00<br>Entry Fee: 550 /=<br>Seats: Two</p>
              <button id="btnt">View Tournament</button>
            </div>
        </div>
    </div>
    
    
</div>