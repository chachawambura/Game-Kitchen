<?php 

echo "gaming_withdrawal submitted !!";
?>