<div class="col-md-12">

<h2 class="subheading">About us</h2>

<p>
The gaming kitchen is an online video game social platform that brings together gamers to challenge
each other competitively while playing a wide variety of their favorite games
Making money gaming has never been easier, sign up, deposit, play and win.</p>
</div>
