<?php 

echo 'read !!';

?>