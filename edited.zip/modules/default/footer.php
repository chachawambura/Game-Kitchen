<footer class="bottom">
    <div class="container-fluid">
    <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-5 socialicon">
                <ul>
                    <li><a href="#"><img src="images/facebook.png"></a></li>
                    <li><a href="#"><img src="images/twitter.png"></a></li>
                    <li><a href="#"><img src="images/google.png"></a></li>
                    <li><a href="#"><img src="images/youtube.png"></a></li>
                    <li><a href="#"><img src="images/linked.png"></a></li>
                    <li><a href="#"><img src="images/instagram.png"></a></li>
                    <li><a href="index.php?pg=terms">Terms & Conditions</a></li>
                </ul>
            </div>
            <div class="col-md-1 socialba"></div>
            <div class="col-md-5 socialba2">Copyright. &copy; <?php echo date("Y").' '.SITE_NAME; ?>. All Rights Reserved.
             
            </div>
        </div>

    </div>
</footer>
<script src="js/nav.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.1.min.js"></script>

<script src="js/datetimepicker.js"></script>

</body>
</html>