<?php 

echo 'orange',$playerId;
$mycolor="#FFA500";

echo playModel::addOrangeStroke($playerId ,$mycolor);

?>