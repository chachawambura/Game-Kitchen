<?php 

echo 'red',$playerId;
$mycolor="#FF0000";
echo playModel::addRedStroke($playerId, $mycolor);

?>