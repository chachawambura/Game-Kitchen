<?php 
//echo $playerId;

echo userModel::submitEnablePlayer($playerId);

?>