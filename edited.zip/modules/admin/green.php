<?php 

echo 'green',$playerId;
$mycolor="#008000";

echo playModel::addGreenStroke($playerId, $mycolor);

?>