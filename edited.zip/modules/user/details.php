<?php include 'events.php'; ?><br />
<?php include 'tasks.php'; ?><br />
<?php include 'myactivities.php'; ?><br />