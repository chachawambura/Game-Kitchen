<?php
echo  playModel::cancelDirectChallenge($currentgameId, $playerId, $stake);
?>