<?php 

echo playModel::acceptDirectMessage($gid);

?>