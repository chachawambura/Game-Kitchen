<?php
echo playModel::submitReadNotification($gid);
?>
