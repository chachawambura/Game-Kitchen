<?php
echo  playModel::declineDirectChallenge($gid, $playerId, $stake);
?>