<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Date

      </th>
      <th class="th-sm">Time

      </th>
      <th class="th-sm">Game

      </th>
      <th class="th-sm">Opponent
      </th>
      <th class="th-sm">Stake
      </th>
      <th class="th-sm">Status

      </th>
    </tr>
  </thead>
  <tbody>
  </tbody>
  </table>
  <a href="index.php?acc=games&page=creatematch">Create Match</a>
  